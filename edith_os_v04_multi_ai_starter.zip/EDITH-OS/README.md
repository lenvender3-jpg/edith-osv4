# EDITH OS v0.4 — Multi-AI Orchestrator Starter

This is an Android source project scaffold, not a compiled APK.

## Design
- Android app: Kotlin + Jetpack Compose.
- Edith/Vision/Nuha personas.
- Multi-AI provider interface and a coordinator that can fan out requests to configured providers.
- Safe local planner fallback.
- WhatsApp click-to-chat draft flow.
- Optional notification listener; user must explicitly enable it in Android Settings.
- Minimal audit log stores action labels only.

## Important limits
- No AI providers are configured out of the box. A provider adapter and valid API access are needed.
- Do not place provider API keys inside the Android app. Use a backend that keeps secrets server-side.
- This project does not read all WhatsApp chats or control all apps.
- Screen capture and game interaction are not implemented here.
- No APK has been built or device-tested in this environment.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 36, sync Gradle, then Build > Build APK(s).
Alternatively, upload the project contents to GitHub and run the Android Debug APK workflow.
