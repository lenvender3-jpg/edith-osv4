package com.edith.os.ai

/**
 * Implement this interface for a provider that you are authorized to use.
 * Keep API credentials on a trusted backend; never hardcode them in the APK.
 */
interface AiProvider {
    val id: String
    suspend fun generate(systemInstruction: String, userPrompt: String): Result<String>
}
