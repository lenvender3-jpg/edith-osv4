package com.edith.os.ai

import com.edith.os.Persona
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

data class ProviderAnswer(val providerId: String, val text: String, val succeeded: Boolean)

/**
 * Sends the same task to explicitly configured providers, then returns their
 * responses for comparison. This is orchestration logic only; no provider is
 * configured until a real adapter/backend is supplied.
 */
class MultiAiCoordinator(
    private val providers: List<AiProvider>
) {
    suspend fun consult(
        persona: Persona,
        prompt: String
    ): List<ProviderAnswer> = coroutineScope {
        providers.map { provider ->
            async {
                val result = provider.generate(persona.instruction, prompt)
                result.fold(
                    onSuccess = { ProviderAnswer(provider.id, it, true) },
                    onFailure = {
                        ProviderAnswer(
                            provider.id,
                            "Provider request failed: ${it.message ?: "unknown error"}",
                            false
                        )
                    }
                )
            }
        }.awaitAll()
    }
}
