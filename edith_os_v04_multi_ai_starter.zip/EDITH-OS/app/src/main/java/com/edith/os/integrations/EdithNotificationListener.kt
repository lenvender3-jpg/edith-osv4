package com.edith.os.integrations

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Requires explicit user enablement in Android Settings.
 * This starter intentionally does not store notification text or message bodies.
 */
class EdithNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Future: process only metadata needed for a user-approved feature.
        // No notification content is persisted by this starter.
    }
}
