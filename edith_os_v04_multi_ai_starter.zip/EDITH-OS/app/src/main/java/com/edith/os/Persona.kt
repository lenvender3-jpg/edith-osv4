package com.edith.os

enum class Persona(val label: String, val instruction: String) {
    EDITH("Edith", "Coordinate the task, identify goals, and produce a clear plan."),
    VISION("Vision", "Analyze evidence, compare options, and identify risks."),
    NUHA("Nuha", "Help with communication, organization, and clear wording.")
}
