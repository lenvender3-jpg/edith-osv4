package com.edith.os.ai

import com.edith.os.Persona

object LocalPlanner {
    fun reply(persona: Persona, message: String): String {
        val text = message.trim()
        if (text.isEmpty()) return "Tulis pesan terlebih dahulu."
        val lower = text.lowercase()
        return when {
            "whatsapp" in lower || lower == "wa" ->
                "Aku bisa membuka WhatsApp atau menyiapkan draf. Periksa penerima dan kirim sendiri."
            "game" in lower ->
                "Aku bisa membantu strategi dari informasi yang kamu berikan. Kontrol langsung bergantung pada dukungan Android dan game."
            "bandingkan ai" in lower ->
                "Mode kolaborasi sudah dirancang, tetapi belum aktif sebelum provider resmi dikonfigurasi."
            else -> when (persona) {
                Persona.EDITH -> "Mari pecah tujuan ini menjadi langkah-langkah yang bisa diuji."
                Persona.VISION -> "Mari periksa fakta, asumsi, pilihan, dan risiko sebelum mengambil keputusan."
                Persona.NUHA -> "Aku bisa membantu merapikan pesan atau rencana. Apa hasil yang ingin kamu capai?"
            }
        }
    }
}
