package com.edith.os

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.edith.os.ai.LocalPlanner
import com.edith.os.integrations.WhatsAppHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { EdithHome(
            onOpenWhatsApp = { WhatsAppHelper.open(this) },
            onDraftWhatsApp = { phone, body -> WhatsAppHelper.draft(this, phone, body) },
            onNotificationSettings = {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        ) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EdithHome(
    onOpenWhatsApp: () -> Boolean,
    onDraftWhatsApp: (String, String) -> Boolean,
    onNotificationSettings: () -> Unit
) {
    var persona by remember { mutableStateOf(Persona.EDITH) }
    var prompt by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Local mode aktif. AI eksternal belum dikonfigurasi.") }
    val history = remember { mutableStateListOf<String>() }

    Scaffold(topBar = { TopAppBar(title = { Text("EDITH OS v0.4") }) }) { insets ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(insets).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Pilih persona", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Persona.entries.forEach { p ->
                        OutlinedButton(onClick = { persona = p }) { Text(p.label) }
                    }
                }
                Text(persona.instruction)
            }
            item {
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    label = { Text("Tulis tugas atau pertanyaan") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    if (prompt.isNotBlank()) {
                        history.add("Kamu: ${prompt.trim()}")
                        history.add("${persona.label}: ${LocalPlanner.reply(persona, prompt)}")
                        prompt = ""
                        status = "Dijawab secara lokal; provider AI belum tersambung."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Kirim ke ${persona.label}") }
            }
            items(history.toList()) { Text(it) }
            item {
                HorizontalDivider()
                Text("Kolaborasi multi-AI", style = MaterialTheme.typography.titleMedium)
                Text("Koordinator tersedia sebagai fondasi kode. Untuk benar-benar menghubungi AI lain, diperlukan adapter/API resmi dan backend aman; belum ada provider aktif.")
            }
            item {
                HorizontalDivider()
                Text("WhatsApp", style = MaterialTheme.typography.titleMedium)
                Button(onClick = {
                    status = if (onOpenWhatsApp()) "Membuka WhatsApp" else "Tidak dapat membuka WhatsApp"
                }, modifier = Modifier.fillMaxWidth()) { Text("Buka WhatsApp") }
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    label = { Text("Nomor internasional, mis. 62812...") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    label = { Text("Draf pesan") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    status = if (onDraftWhatsApp(phone, draft))
                        "Draf dibuka. Periksa sebelum mengirim."
                    else "Periksa nomor dan pesan."
                }, modifier = Modifier.fillMaxWidth()) { Text("Siapkan draf WhatsApp") }
            }
            item {
                HorizontalDivider()
                Text("Izin notifikasi", style = MaterialTheme.typography.titleMedium)
                Text("Opsional. Kamu harus mengaktifkannya sendiri di pengaturan Android.")
                OutlinedButton(
                    onClick = onNotificationSettings,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Buka pengaturan akses notifikasi") }
                Text("Status: $status")
            }
        }
    }
}
