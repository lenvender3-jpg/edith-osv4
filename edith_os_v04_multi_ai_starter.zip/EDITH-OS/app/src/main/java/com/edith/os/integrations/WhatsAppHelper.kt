package com.edith.os.integrations

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object WhatsAppHelper {
    fun open(context: Context): Boolean = try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")))
        true
    } catch (_: ActivityNotFoundException) { false }

    fun draft(context: Context, phone: String, message: String): Boolean {
        val digits = phone.filter(Char::isDigit)
        if (digits.isBlank() || message.isBlank()) return false
        val uri = Uri.Builder().scheme("https").authority("wa.me")
            .appendPath(digits).appendQueryParameter("text", message).build()
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: ActivityNotFoundException) { false }
    }
}
